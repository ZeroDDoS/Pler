cd /root/cef-browser/s110 && rm CMakeCache.txt && cmake . && cd tests/cefsimple && make -j 64 && cp -r Release/ /root/cef-browser/bins/110
cd /root/cef-browser/s111 && rm CMakeCache.txt && cmake . && cd tests/cefsimple && make -j 64 && cp -r Release/ /root/cef-browser/bins/111
cd /root/cef-browser/s112 && rm CMakeCache.txt && cmake . && cd tests/cefsimple && make -j 64 && cp -r Release/ /root/cef-browser/bins/112
cd /root/cef-browser/s113 && rm CMakeCache.txt && cmake . && cd tests/cefsimple && make -j 64 && cp -r Release/ /root/cef-browser/bins/113
cd /root/cef-browser/s114 && rm CMakeCache.txt && cmake . && cd tests/cefsimple && make -j 64 && cp -r Release/ /root/cef-browser/bins/114
cd /root/cef-browser/s115 && rm CMakeCache.txt && cmake . && cd tests/cefsimple && make -j 64 && cp -r Release/ /root/cef-browser/bins/115
cd /root/cef-browser/s116 && rm CMakeCache.txt && cmake . && cd tests/cefsimple && make -j 64 && cp -r Release/ /root/cef-browser/bins/116