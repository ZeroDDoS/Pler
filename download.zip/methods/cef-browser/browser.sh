chown root:root /root/cef-browser/ -R
chmod +x /root/cef-browser/h2nxver
cd /root/cef-browser; xvfb-run -a -s "-maxclients 2048" node browser.js $@
