<?php

if (!defined('allow')) {
    header("HTTP/1.0 404 Not Found");
}

if (!defined('k90plearptJQXxFZR2l7LRp8V')) {
    die('includes not found');
}

class BlackList
{

    public function BlackListDataAll()
    {
        global $DataBase;

        $DataBase->Query("SELECT * FROM `blacklist` ORDER BY `id` ASC");
        $DataBase->Execute();

        $Return = array(
            'Count' => $DataBase->RowCount(),
            'Response' => $DataBase->ResultSet()
        );

        return $Return;
    }

    public function BlackListData($pID)
    {
        global $DataBase;

        $DataBase->Query("SELECT * FROM `blacklist` WHERE `id` = :pID");
        $DataBase->Bind(':pID', $pID);
        $DataBase->Execute();

        $Return = array(
            'Count' => $DataBase->RowCount(),
            'Response' => $DataBase->ResultSet()
        );

        return $Return;
    }

    public function BlackListDataID($pID)
    {
        global $DataBase;

        $DataBase->Query("SELECT * FROM `blacklist` WHERE `id` = :pID");
        $DataBase->Bind(':pID', $pID);
        $DataBase->Execute();

        return $DataBase->Single();
    }

    public function AddBlackList($word, $detail, $expires)
    {
        global $DataBase;

        // Insert in Base
        $DataBase->Query("INSERT INTO `blacklist` (`id`, `word`, `detail`, `expires`) VALUES (NULL, :word, :detail, :expires);");
        $DataBase->Bind(':word', $word);
        $DataBase->Bind(':detail', $detail);
        $DataBase->Bind(':expires', $expires);

        return $DataBase->Execute();
    }


    public function DeleteBlackList($id)
    {
        global $DataBase;

        $DataBase->Query("DELETE FROM `blacklist` WHERE `id`=:uID");
        $DataBase->Bind(':uID', $id);

        return $DataBase->Execute();
    }

}

?>
