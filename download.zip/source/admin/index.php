<?php
 header('location: home');
?>