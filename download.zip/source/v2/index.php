<?php
header('Location: /start');
die();
?>